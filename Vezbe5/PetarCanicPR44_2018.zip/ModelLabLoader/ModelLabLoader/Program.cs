﻿using FTN;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelLabLoader
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello world");
            Console.WriteLine("---- Created Concrete Class ---------");
            Console.WriteLine();
            #region BaseVoltage
            Console.WriteLine("----------- Base Voltage ------------");
            Console.WriteLine( "************ Printf Base Voltage Instances ************");
            BaseVoltage baseVoltage1 = new BaseVoltage();
            BaseVoltage baseVoltage2 = new BaseVoltage();
            BaseVoltage baseVoltage3 = new BaseVoltage();
            baseVoltage1.MRID = "BaseVoltage1";
            baseVoltage2.MRID = "BaseVoltage2";
            baseVoltage3.MRID = "BaseVoltage3";
            baseVoltage1.Name = "BaseVoltage11";
            baseVoltage2.Name = "BaseVoltage22";
            baseVoltage3.Name = "BaseVoltage33";
            baseVoltage1.NominalVoltage = float.Parse("2,33");
            baseVoltage2.NominalVoltage = float.Parse("3,33");
            baseVoltage3.NominalVoltage = float.Parse("4,33");
            Console.WriteLine(baseVoltage1.ToString());
            Console.WriteLine(baseVoltage2.ToString());
            Console.WriteLine(baseVoltage3.ToString());
            Console.WriteLine("************ End Base Voltage Instances ************");
            Console.WriteLine();
            #endregion
            Console.WriteLine("------------- Location --------------");
            #region Location
            Console.WriteLine("*********** Instances of Location *************");
            Console.WriteLine();
            Location location1 = new Location();
            Location location2 = new Location();
            Location location3 = new Location();
            location1.MRID = "Location1";
            location2.MRID = "Location2";
            location3.MRID = "Location3";
            location1.Name = "Location11";
            location2.Name = "Location22";
            location3.Name = "Location33";
            location1.ID = "1";
            location2.ID = "3";
            location3.ID = "3";
            List<Location> locations = new List<Location>() { location1, location2, location3 };
            Console.WriteLine(location1.ToString());
            Console.WriteLine(location2.ToString());
            Console.WriteLine(location3.ToString());
            Console.WriteLine("*************** End of Location Instances **************");
            Console.WriteLine();
            Console.WriteLine();
            #endregion
            Console.WriteLine("---------- Power Transformer --------");
          
            Console.WriteLine("------- Conducting Equipment --------");
            #region ConductingEquipment
            ConductingEquipment conductingEquipment1 = new ConductingEquipment();
            ConductingEquipment conductingEquipment2 = new ConductingEquipment();
            ConductingEquipment conductingEquipment3 = new ConductingEquipment();
            conductingEquipment1.ID = "1";
            conductingEquipment2.ID = "2";
            conductingEquipment3.ID = "3";
            conductingEquipment1.Name = "ConductingEquipment1";
            conductingEquipment2.Name = "ConductingEquipment2";
            conductingEquipment3.Name = "ConductingEquipment3";
            conductingEquipment1.MRID = "ConductingEquipment11";
            conductingEquipment2.MRID = "ConductingEquipment22";
            conductingEquipment3.MRID = "ConductingEquipment33";
            conductingEquipment1.Location = location2;
            conductingEquipment2.Location = location1;
            conductingEquipment3.Location = location3;
            conductingEquipment1.BaseVoltage = baseVoltage1;
            conductingEquipment2.BaseVoltage = baseVoltage2;
            conductingEquipment3.BaseVoltage = baseVoltage3;
            Console.WriteLine(conductingEquipment1);
            Console.WriteLine(conductingEquipment2);
            Console.WriteLine(conductingEquipment3);
            Console.WriteLine();
            Console.WriteLine();
            #endregion
          

            Console.WriteLine("------------ Winding Test -----------");
            List<PowerTransformer> powerTransformers = new List<PowerTransformer>();
            Console.WriteLine("- ------------- Transformers -------------------");
            for (int i = 0; i < 20; i++)
            {
                PowerTransformer powerTransformer1 = new PowerTransformer();
                powerTransformer1.ID = i.ToString();
              
                powerTransformer1.MRID = "PowerTransformer"+i.ToString();
          
                powerTransformer1.Name = "PowerTranformer " + i.ToString()+ i.ToString();
   
                powerTransformer1.Location = locations[i % 3];
                powerTransformers.Add(powerTransformer1);
                //Console.WriteLine(powerTransformer1);

            }
            Console.WriteLine();
            Console.WriteLine();

            List<TransformerWinding> windings = new List<TransformerWinding>();
            int index = 0;
            for (int i = 0; i < 40; i++)
            {
                TransformerWinding transformerWinding = new TransformerWinding();

                int pom = i % 2;
                if (pom == 0)
                {
                    transformerWinding.BaseVoltage = baseVoltage1;
                    transformerWinding.PowerTransformer = powerTransformers[index];
                }
                else
                {
                    transformerWinding.BaseVoltage = baseVoltage2;
                    transformerWinding.PowerTransformer = powerTransformers[index++];
                }
                transformerWinding.MRID = "TransformerWinding" + pom.ToString() + i.ToString();
                transformerWinding.Name = "TransformerWinding" + i.ToString();
                transformerWinding.ID = i.ToString();
                windings.Add(transformerWinding);

            }

            List<WindingTest> tests = new List<WindingTest>();
            for (int i = 0; i < 40; i++)
            {
                WindingTest test = new WindingTest();
                test.ID = i.ToString();
                test.Name = "WindingTest" + i.ToString();
                test.MRID = "WindingTest" + i.ToString() + i.ToString();
                test.From_TransformerWinding = windings[i];
               // Console.WriteLine(test);
                tests.Add(test);
            }

            WriteToFile("Exe.txt",tests);

            Console.ReadKey(true);
        }
        static void WriteToFile(string filename,List<WindingTest> list)
        {
            try
            {
                StreamWriter sw = File.CreateText(filename);
                foreach (var item in list)
                {
                    sw.WriteLine(item);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
